import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobdesc',
  templateUrl: './jobdesc.component.html',
  styleUrls: ['./jobdesc.component.css']
})
export class JobdescComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
